/*
==========================================================
  Trabalho Prático I - Algoritmos e Programacao
  Exercicio 1 - Validação de Nota
==========================================================

  INSTRUCOES:
  - Escreva seu codigo abaixo desta secao de comentarios.
  - Antes de colar aqui, certifique-se de que o programa
    compila e executa corretamente no Dev-C++.
==========================================================
*/

// Cole seu codigo aqui:

#include <stdio.h>

int main() {
  int numero_alunos, i;
  int aprovados = 0;
  int reprovados = 0;
  float nota;

  printf("Numero de alunos: ");
  scanf("%d", &numero_alunos);

  for (i = 1; i <= numero_alunos; i++) {
    do {
      printf("Aluno %d - Nota: ", i);
      scanf("%f", &nota);

      if (nota < 0 || nota > 10) {
        printf("Nota invalida. Digite novamente.\n");
      }
    } while (nota < 0 || nota > 10);

    if (nota >= 7) {
      aprovados++;
    } else {
      reprovados++;
    }
  }

  printf("\nAprovados: %d\n", aprovados);
  printf("Reprovados: %d\n", reprovados);

  return 0;
}
