/*
==========================================================
  Trabalho Prático I - Algoritmos e Programacao
  Exercicio 2 - Soma de Ímpares no Intervalo
==========================================================

  INSTRUCOES:
  - Escreva seu codigo abaixo desta secao de comentarios.
  - Antes de colar aqui, certifique-se de que o programa
    compila e executa corretamente no Dev-C++.
==========================================================
*/

// Cole seu codigo aqui:

#include <stdio.h>

int main() {
  int a, b, i;
  int quantidade_impares = 0;
  int soma_impares = 0;

  printf("Digite o valor de A: ");
  scanf("%d", &a);

  printf("Digite o valor de B: ");
  scanf("%d", &b);

  if (a > b) {
    printf("Valor de A deve ser menor ou igual a B.\n");
    return 0;
  }

  for (i = a; i <= b; i++) {
    if (i % 2 != 0) {
      quantidade_impares++;
      soma_impares += i;
    }
  }

  if (quantidade_impares == 0) {
    printf("Nenhum impar encontrado.\n");
  } else {
    printf("Impares encontrados: %d\n", quantidade_impares);
    printf("Soma dos impares: %d\n", soma_impares);
  }

  return 0;
}
