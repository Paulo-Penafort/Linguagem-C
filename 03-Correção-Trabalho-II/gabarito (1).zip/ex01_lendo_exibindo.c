#include <stdio.h>

int main() {
    char inicial;
    int matricula;
    float salario;

    printf("Digite a inicial do funcionario: ");
    scanf(" %c", &inicial);   // espaco antes de %c ignora \n anterior
    printf("Digite a matricula do funcionario: ");
    scanf("%d", &matricula);
    printf("Digite o salario do funcionario: ");
    scanf("%f", &salario);

    printf("Funcionario: %c  Matricula: %d  Salario: R$ %.2f\n", inicial, matricula, salario);

    return 0;
}
