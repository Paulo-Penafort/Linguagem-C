#include <stdio.h>

int main() {
    float celsius, fahrenheit;

    printf("Digite a temperatura em Celsius: ");
    scanf("%f", &celsius);

    // Usa 9.0/5.0 para forcar divisao real (nao inteira)
    fahrenheit = celsius * 9.0 / 5.0 + 32;

    printf("A temperatura em Fahrenheit é: %.1f\n", fahrenheit);

    return 0;
}
