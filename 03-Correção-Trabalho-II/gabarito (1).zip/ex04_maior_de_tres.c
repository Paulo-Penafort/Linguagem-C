#include <stdio.h>

int main() {
    int a, b, c, maior;

    printf("Digite tres numeros inteiros: ");
    scanf("%d %d %d", &a, &b, &c);

    maior = a; // assume o primeiro como maior

    if (b > maior) {
        maior = b; // se b for maior, atualiza maior
    }
    
    if (c > maior) {
        maior = c; // se c for maior, atualiza maior
    }

    printf("O maior numero é: %d\n", maior);

    return 0;
}
