#include <stdio.h>

int main() {
    int num, maior, menor;
    int primeiro = 1;   // flag: indica se ainda nao lemos nenhum valor valido

    printf("Digite numeros inteiros (0 para terminar): ");
    scanf("%d", &num);

    while (num != 0) {
        if (primeiro) {
            maior    = num;  // primeiro valor valido inicializa maior...
            menor    = num;  // ...e menor ao mesmo tempo
            primeiro = 0;
        } else {
            if (num > maior) {  // se num for maior, atualiza maior
                maior = num;
            }
            if (num < menor) {  // se num for menor, atualiza menor
                menor = num;
            }
        }
        
        printf("Digite outro numero inteiro (0 para terminar): ");
        scanf("%d", &num);
    }

    printf("Maior: %d\n", maior);
    printf("Menor: %d\n", menor);

    return 0;
}
