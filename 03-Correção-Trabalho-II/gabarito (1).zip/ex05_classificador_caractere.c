#include <stdio.h>

int main() {
    char c;

    printf("Digite um caractere: ");
    scanf(" %c", &c);   // espaco ignora espacos/enters da entrada

    if (c >= 'A' && c <= 'Z') {
        printf("letra maiuscula\n");
    } else if (c >= 'a' && c <= 'z') {
        printf("letra minuscula\n");
    } else if (c >= '0' && c <= '9') {
        printf("digito\n");
    } else {
        printf("outro\n");
    }

    return 0;
}
