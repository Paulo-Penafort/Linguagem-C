#include <stdio.h>

int main() {
    int n, valor;
    int soma_pares   = 0;
    int cont_impares = 0;

    printf("Digite a quantidade de numeros: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Digite o %dº numero: ", i + 1);
        scanf("%d", &valor);
        if (valor % 2 == 0) {
            soma_pares += valor;    // acumula pares
        } else {
            cont_impares++;         // conta impares
        }
    }
    
    printf("Soma dos pares: %d\n",        soma_pares);
    printf("Quantidade de impares: %d\n", cont_impares);

    return 0;
}
