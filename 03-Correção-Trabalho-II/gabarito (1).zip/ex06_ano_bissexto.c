#include <stdio.h>

int main() {
    int ano;

    printf("Digite um ano: ");
    scanf("%d", &ano);

    // bissexto: (div 4 E nao div 100) OU (div 400)
    if ((ano % 4 == 0 && ano % 100 != 0) || ano % 400 == 0) {
        printf("bissexto\n");
    } else {
        printf("nao bissexto\n");
    }

    return 0;
}
