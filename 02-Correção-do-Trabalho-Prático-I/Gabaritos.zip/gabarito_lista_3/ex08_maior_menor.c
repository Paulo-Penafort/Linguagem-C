/*
 * Exercício 08 — Maior e Menor Valor (encerra com número negativo)
 * ------------------------------------------------------------------
 * Objetivo: ler valores inteiros positivos continuamente até que
 * um valor negativo seja informado. Ao final, exibir o maior e
 * o menor valor entre os positivos lidos.
 *
 * Conceito trabalhado: controle de maior e menor com variáveis
 * auxiliares — inicializadas com o primeiro valor lido e atualizadas
 * a cada iteração por comparação direta.
 */

#include <stdio.h>

int main() {

    int valor;          /* cada número lido pelo usuário */
    int maior;          /* maior valor encontrado até o momento */
    int menor;          /* menor valor encontrado até o momento */
    int quantidade;     /* conta quantos valores positivos foram lidos */

    quantidade = 0;

    printf("Digite valores inteiros positivos (negativo para encerrar):\n");

    printf("Valor: ");
    scanf("%d", &valor);

    /* Verificamos se o primeiro valor já é negativo (entrada vazia) */
    if (valor < 0) {
        printf("Nenhum valor positivo foi informado.\n");
        return 0;
    }

    /* Inicializamos maior e menor com o primeiro valor válido lido.
     * Isso garante que a comparação sempre parte de um valor real,
     * não de um número arbitrário como 0 ou 99999. */
    maior = valor;
    menor = valor;
    quantidade = 1;

    /* Lemos os próximos valores; paramos ao encontrar um negativo */
    printf("Valor: ");
    scanf("%d", &valor);

    while (valor >= 0) {

        /* Verificamos se o valor atual supera o maior registrado */
        if (valor > maior) {
            maior = valor;
        }

        /* Verificamos se o valor atual é menor que o menor registrado */
        if (valor < menor) {
            menor = valor;
        }

        quantidade = quantidade + 1;

        printf("Valor: ");
        scanf("%d", &valor);
    }

    printf("\n%d valor(es) lido(s).\n", quantidade);
    printf("Maior valor: %d\n", maior);
    printf("Menor valor: %d\n", menor);

    return 0;
}
