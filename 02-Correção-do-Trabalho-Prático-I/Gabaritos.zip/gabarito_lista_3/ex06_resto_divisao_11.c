/*
 * Exercício 06 — Números com Resto 5 na Divisão por 11 (1000 a 1999)
 * --------------------------------------------------------------------
 * Objetivo: encontrar e exibir todos os inteiros no intervalo [1000, 1999]
 * cuja divisão por 11 resulta em resto igual a 5.
 *
 * Conceito trabalhado: laço em intervalo fixo com teste de resto —
 * o operador % permite verificar o resto de qualquer divisão inteira.
 */

#include <stdio.h>

int main() {

    int numero;      /* número testado a cada iteração */
    int resto;       /* resto da divisão de numero por 11 */
    int quantidade;  /* conta quantos números satisfazem a condição */

    quantidade = 0;

    printf("Numeros entre 1000 e 1999 com resto 5 na divisao por 11:\n");

    /* Percorremos todos os inteiros do intervalo [1000, 1999] */
    for (numero = 1000; numero <= 1999; numero++) {

        /* Calculamos o resto da divisão por 11 */
        resto = numero % 11;

        /* Se o resto for 5, o número satisfaz a condição */
        if (resto == 5) {
            printf("%d\n", numero);
            quantidade = quantidade + 1;
        }
    }

    printf("\nTotal encontrado: %d numero(s).\n", quantidade);

    return 0;
}
