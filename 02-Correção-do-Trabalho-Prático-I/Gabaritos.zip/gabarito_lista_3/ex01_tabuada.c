/*
 * Exercício 01 — Tabuada da Multiplicação
 * -----------------------------------------
 * Objetivo: ler um número inteiro e exibir sua tabuada de 0 a 10.
 *
 * Conceito trabalhado: laço com variável de controle crescente,
 * cálculo do produto a cada iteração.
 */

#include <stdio.h>

int main() {

    int numero;    /* número cuja tabuada será exibida */
    int i;         /* multiplicador: varia de 0 a 10 */
    int resultado; /* produto calculado em cada passo: numero * i */

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    printf("\nTabuada do %d:\n", numero);

    /* Percorremos todos os multiplicadores de 0 até 10 */
    for (i = 0; i <= 10; i++) {

        /* Calculamos o produto e guardamos em uma variável intermediária
         * antes de exibir, para deixar o printf mais legível */
        resultado = numero * i;

        printf("%d x %d = %d\n", numero, i, resultado);
    }

    return 0;
}
