/*
 * Exercício 11 — Mês do Ano com Switch
 * ----------------------------------------
 * Objetivo: ler um número inteiro e informar a qual mês do ano
 * ele corresponde. Valores fora do intervalo [1, 12] são inválidos.
 *
 * Conceito trabalhado: estrutura switch — cada case corresponde
 * a um valor possível da variável, permitindo selecionar o caminho
 * correto de forma clara e organizada. O default trata entradas
 * fora dos valores esperados.
 */

#include <stdio.h>

int main() {

    int mes; /* número do mês informado pelo usuário */

    printf("Digite o numero do mes (1 a 12): ");
    scanf("%d", &mes);

    /* O switch testa o valor de 'mes' e executa o case correspondente.
     * Cada case termina com 'break' para evitar "cair" no próximo. */
    switch (mes) {

        case 1:
            printf("Janeiro\n");
            break;

        case 2:
            printf("Fevereiro\n");
            break;

        case 3:
            printf("Marco\n");
            break;

        case 4:
            printf("Abril\n");
            break;

        case 5:
            printf("Maio\n");
            break;

        case 6:
            printf("Junho\n");
            break;

        case 7:
            printf("Julho\n");
            break;

        case 8:
            printf("Agosto\n");
            break;

        case 9:
            printf("Setembro\n");
            break;

        case 10:
            printf("Outubro\n");
            break;

        case 11:
            printf("Novembro\n");
            break;

        case 12:
            printf("Dezembro\n");
            break;

        /* default é executado quando nenhum case foi satisfeito */
        default:
            printf("O valor %d nao corresponde a nenhum mes.\n", mes);
            break;
    }

    return 0;
}
