/*
 * Exercício 10 — Verificar se um Número é Primo
 * ------------------------------------------------
 * Objetivo: ler um inteiro e informar se ele é primo ou não.
 *
 * Definição: um número é primo se for maior que 1 e divisível
 * apenas por 1 e por ele mesmo.
 *
 * Estratégia:
 *   Testamos divisores de 2 até (numero - 1).
 *   Se encontrarmos qualquer divisor exato (resto == 0), o número
 *   não é primo e podemos parar de testar imediatamente.
 *
 * Conceito trabalhado: laço com flag de controle — usamos a variável
 * 'divisivel' para registrar se foi encontrado algum divisor, e
 * interrompemos o laço assim que isso acontecer.
 */

#include <stdio.h>

int main() {

    int numero;       /* número a ser testado */
    int divisor;      /* candidato a divisor; varia de 2 até numero-1 */
    int resto;        /* resto da divisão de numero por divisor */
    int divisivel;    /* flag: 0 = não encontrou divisor (primo até agora)
                                1 = encontrou divisor (não é primo) */

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    /* Casos especiais: números <= 1 não são primos por definição */
    if (numero <= 1) {
        printf("%d nao e primo.\n", numero);
        return 0;
    }

    /* O número 2 é o único primo par — tratamos como caso especial */
    if (numero == 2) {
        printf("%d e primo.\n", numero);
        return 0;
    }

    divisivel = 0; /* assumimos que é primo até provar o contrário */

    /* Testamos todos os candidatos a divisor de 2 até numero-1 */
    for (divisor = 2; divisor < numero; divisor++) {

        resto = numero % divisor;

        if (resto == 0) {
            /* Encontramos um divisor exato: o número não é primo */
            divisivel = 1;

            /* Não precisamos continuar testando — saímos do laço */
            break;
        }
    }

    /* Decidimos a saída com base no flag */
    if (divisivel == 0) {
        printf("%d e primo.\n", numero);
    } else {
        printf("%d nao e primo.\n", numero);
    }

    return 0;
}
