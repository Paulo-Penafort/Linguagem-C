/*
 * Exercício 09 — Contar Números Negativos (sentinela 0)
 * -------------------------------------------------------
 * Objetivo: ler inteiros continuamente até que zero seja informado.
 * O zero é desconsiderado. Ao final, exibir quantos números negativos
 * foram digitados.
 *
 * Conceito trabalhado: laço com sentinela e contador condicional —
 * o zero encerra o laço sem ser contabilizado; negativos incrementam
 * o contador.
 */

#include <stdio.h>

int main() {

    int numero;          /* número lido a cada iteração */
    int qtd_negativos;   /* conta quantos números negativos foram informados */

    qtd_negativos = 0;

    printf("Digite numeros inteiros (0 para encerrar):\n");

    printf("Numero: ");
    scanf("%d", &numero);

    /* Continuamos enquanto o número não for zero */
    while (numero != 0) {

        /* Verificamos se o número atual é negativo */
        if (numero < 0) {
            qtd_negativos = qtd_negativos + 1;
        }

        printf("Numero: ");
        scanf("%d", &numero);
    }

    printf("\nQuantidade de numeros negativos informados: %d\n", qtd_negativos);

    return 0;
}
