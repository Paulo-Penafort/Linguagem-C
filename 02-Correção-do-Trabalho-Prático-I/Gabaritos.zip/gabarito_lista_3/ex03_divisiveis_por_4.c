/*
 * Exercício 03 — Números Divisíveis por 4 Menores que 200
 * ---------------------------------------------------------
 * Objetivo: exibir todos os inteiros no intervalo [1, 199]
 * que são divisíveis por 4, ou seja, cujo resto da divisão por 4 é zero.
 *
 * Conceito trabalhado: laço com condição de divisibilidade usando
 * o operador % (resto da divisão inteira).
 */

#include <stdio.h>

int main() {

    int numero;        /* número testado a cada iteração */
    int resto;         /* resto da divisão de numero por 4 */
    int quantidade;    /* conta quantos números foram encontrados */

    quantidade = 0;

    printf("Numeros divisíveis por 4 menores que 200:\n");

    /* Percorremos todos os inteiros de 1 até 199 */
    for (numero = 1; numero < 200; numero++) {

        /* Calculamos o resto da divisão por 4 */
        resto = numero % 4;

        /* Se o resto for zero, o número é divisível por 4 */
        if (resto == 0) {
            printf("%d\n", numero);
            quantidade = quantidade + 1;
        }
    }

    printf("\nTotal de numeros encontrados: %d\n", quantidade);

    return 0;
}
