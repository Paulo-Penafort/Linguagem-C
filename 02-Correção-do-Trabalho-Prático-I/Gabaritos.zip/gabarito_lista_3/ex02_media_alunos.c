/*
 * Exercício 02 — Média Aritmética de 20 Alunos
 * -----------------------------------------------
 * Objetivo: para cada um dos 20 alunos, ler 3 notas e calcular
 * a média aritmética, exibindo-a ao final de cada aluno.
 *
 * Conceito trabalhado: laços aninhados — o laço externo controla
 * o aluno atual, e o laço interno lê as 3 notas acumulando a soma.
 */

#include <stdio.h>

int main() {

    int   aluno;        /* índice do aluno atual (1 a 20) */
    int   nota_idx;     /* índice da nota atual (1 a 3) */
    float nota;         /* valor de cada nota lida */
    float soma_notas;   /* acumulador da soma das 3 notas do aluno */
    float media;        /* média calculada: soma_notas / 3 */

    /* Laço EXTERNO: repete para cada um dos 20 alunos */
    for (aluno = 1; aluno <= 20; aluno++) {

        soma_notas = 0.0; /* zeramos o acumulador para cada novo aluno */

        printf("\n--- Aluno %d ---\n", aluno);

        /* Laço INTERNO: lê as 3 notas do aluno e acumula a soma */
        for (nota_idx = 1; nota_idx <= 3; nota_idx++) {
            printf("  Nota %d: ", nota_idx);
            scanf("%f", &nota);
            soma_notas = soma_notas + nota;
        }

        /* Calculamos a média após as 3 leituras */
        media = soma_notas / 3.0;

        printf("  Media do Aluno %d: %.2f\n", aluno, media);
    }

    return 0;
}
