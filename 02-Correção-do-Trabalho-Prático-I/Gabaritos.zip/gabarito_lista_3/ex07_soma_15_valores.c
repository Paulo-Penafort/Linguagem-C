/*
 * Exercício 07 — Soma de 15 Valores Inteiros Positivos
 * ------------------------------------------------------
 * Objetivo: ler exatamente 15 valores inteiros positivos e
 * exibir a soma total ao final.
 *
 * Conceito trabalhado: acumulador com laço de quantidade fixa —
 * sabemos exatamente quantas iterações o laço vai executar (15).
 */

#include <stdio.h>

int main() {

    int i;        /* índice da leitura atual (1 a 15) */
    int valor;    /* cada número lido pelo usuário */
    int soma;     /* acumulador da soma total */

    soma = 0; /* inicializamos em zero antes de começar a somar */

    printf("Digite 15 numeros inteiros positivos:\n");

    for (i = 1; i <= 15; i++) {
        printf("  Valor %2d: ", i);
        scanf("%d", &valor);

        /* Adicionamos o valor lido à soma acumulada */
        soma = soma + valor;
    }

    printf("\nSoma total dos 15 valores: %d\n", soma);

    return 0;
}
