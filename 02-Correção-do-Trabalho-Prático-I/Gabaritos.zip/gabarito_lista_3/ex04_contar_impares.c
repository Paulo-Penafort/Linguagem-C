/*
 * Exercício 04 — Contar Números Ímpares (sentinela -999)
 * --------------------------------------------------------
 * Objetivo: ler números continuamente e contar quantos são ímpares.
 * A leitura encerra quando o usuário digitar -999.
 *
 * Conceito trabalhado: laço com sentinela — o valor -999 sinaliza
 * o fim da entrada sem ser processado como dado válido.
 * Um número é ímpar quando seu resto na divisão por 2 é diferente de zero.
 */

#include <stdio.h>

int main() {

    int numero;          /* número lido a cada iteração */
    int qtd_impares;     /* acumulador: conta quantos ímpares foram lidos */
    int resto;           /* resto de numero / 2; se != 0, é ímpar */

    qtd_impares = 0;

    printf("Digite numeros inteiros (-999 para encerrar):\n");

    /* Lemos o primeiro número antes do laço (leitura "de entrada") */
    printf("Numero: ");
    scanf("%d", &numero);

    /* O laço continua enquanto o número não for o sentinela */
    while (numero != -999) {

        /* Verificamos se o número atual é ímpar */
        resto = numero % 2;

        if (resto != 0) {
            /* Resto diferente de zero indica número ímpar */
            qtd_impares = qtd_impares + 1;
        }

        /* Lemos o próximo número ao final de cada iteração */
        printf("Numero: ");
        scanf("%d", &numero);
    }

    printf("\nQuantidade de numeros impares: %d\n", qtd_impares);

    return 0;
}
