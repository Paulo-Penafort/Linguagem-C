/*
 * Exercício 05 — Contar Ocorrências do Número 10 (sentinela 0)
 * --------------------------------------------------------------
 * Objetivo: ler números continuamente e contar quantas vezes
 * o número 10 foi digitado. A leitura encerra quando o usuário
 * digitar 0 (zero), que não é contabilizado.
 *
 * Conceito trabalhado: laço com sentinela e contador condicional —
 * só incrementamos o contador quando o número lido for exatamente 10.
 */

#include <stdio.h>

int main() {

    int numero;          /* número lido a cada iteração */
    int qtd_dez;         /* contador de vezes que o 10 foi digitado */

    qtd_dez = 0;

    printf("Digite numeros inteiros (0 para encerrar):\n");

    printf("Numero: ");
    scanf("%d", &numero);

    /* O sentinela aqui é 0; ele encerra o laço sem ser contabilizado */
    while (numero != 0) {

        /* Verificamos se o número digitado é exatamente 10 */
        if (numero == 10) {
            qtd_dez = qtd_dez + 1;
        }

        printf("Numero: ");
        scanf("%d", &numero);
    }

    printf("\nO numero 10 foi digitado %d vez(es).\n", qtd_dez);

    return 0;
}
