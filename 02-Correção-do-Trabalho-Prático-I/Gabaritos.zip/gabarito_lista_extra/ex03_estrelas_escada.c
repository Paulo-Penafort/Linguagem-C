/*
 * Exercício 03 — Estrelas em Escada
 * ------------------------------------
 * Objetivo: ler N e exibir N linhas; a linha i contém i asteriscos.
 *
 * Conceito trabalhado: laços aninhados — o laço externo controla a
 * linha e o laço interno imprime os asteriscos daquela linha.
 */

#include <stdio.h>

int main() {

    int n;        /* número de linhas */
    int linha;    /* controla qual linha estamos desenhando (1 a n) */
    int coluna;   /* controla quantos asteriscos já foram impressos na linha atual */

    printf("Digite o valor de N: ");
    scanf("%d", &n);

    /* Laço EXTERNO: percorre cada linha de 1 até n */
    for (linha = 1; linha <= n; linha++) {

        /* Laço INTERNO: imprime exatamente 'linha' asteriscos.
         * Na linha 1, imprime 1 asterisco.
         * Na linha 2, imprime 2 asteriscos. E assim por diante. */
        for (coluna = 1; coluna <= linha; coluna++) {
            printf("*");
        }

        /* Ao terminar os asteriscos da linha atual, quebra a linha */
        printf("\n");
    }

    return 0;
}
