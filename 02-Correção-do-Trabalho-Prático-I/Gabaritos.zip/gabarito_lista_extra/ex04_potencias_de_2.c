/*
 * Exercício 04 — Potências de 2
 * --------------------------------
 * Objetivo: ler N e exibir 2^1, 2^2, ..., 2^N sem usar pow().
 *
 * Conceito trabalhado: produto acumulado — em vez de recalcular
 * a potência do zero a cada iteração, multiplicamos o resultado
 * anterior por 2.
 */

#include <stdio.h>

int main() {

    int n;          /* expoente máximo */
    int i;          /* variável de controle do laço */
    int potencia;   /* guarda 2^i: começa em 2 e dobra a cada passo */

    printf("Digite o valor de N: ");
    scanf("%d", &n);

    /* Inicializamos com 2^1 = 2 e iremos multiplicar por 2 a cada rodada */
    potencia = 2;

    for (i = 1; i <= n; i++) {

        /* Neste ponto, 'potencia' já vale 2^i */
        printf("2^%d = %d\n", i, potencia);

        /* Preparamos o próximo valor: 2^(i+1) = 2^i * 2 */
        potencia = potencia * 2;
    }

    return 0;
}
