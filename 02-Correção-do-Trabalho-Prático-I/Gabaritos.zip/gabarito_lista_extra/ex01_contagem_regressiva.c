/*
 * Exercício 01 — Contagem Regressiva
 * ------------------------------------
 * Objetivo: ler um número N e exibir uma contagem regressiva de N até 1,
 * exibindo "Fim!" ao encerrar.
 *
 * Conceito trabalhado: laço com variável decrescente (for/while com --).
 */

#include <stdio.h>

int main() {

    int n;          /* número informado pelo usuário */
    int contador;   /* variável de controle do laço; começa em n e vai até 1 */

    /* Leitura do valor N */
    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &n);

    /* Iniciamos o contador em n e decrementamos a cada iteração.
     * O laço continua enquanto contador for maior ou igual a 1. */
    for (contador = n; contador >= 1; contador--) {
        printf("%d\n", contador);
    }

    /* Mensagem final após o laço terminar */
    printf("Fim!\n");

    return 0;
}
