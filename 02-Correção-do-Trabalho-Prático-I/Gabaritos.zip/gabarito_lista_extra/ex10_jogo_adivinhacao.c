/*
 * Exercício 10 — Jogo de Adivinhação
 * ------------------------------------
 * Objetivo: o programa define um número secreto entre 1 e 100.
 * O usuário tem até 7 tentativas para adivinhar.
 * A cada tentativa, o programa informa se o chute é maior ou menor.
 *
 * Conceito trabalhado: laço com estado e entrada interativa —
 * múltiplas condições de saída controladas por flags e contadores.
 */

#include <stdio.h>

int main() {

    int secreto      = 42;   /* número secreto definido pelo programador */
    int max_tent     = 7;    /* limite máximo de tentativas */
    int chute;               /* valor digitado pelo usuário a cada rodada */
    int tentativas;          /* contador de tentativas realizadas */
    int acertou;             /* flag: 1 = acertou, 0 = ainda não acertou */

    tentativas = 0;
    acertou    = 0;

    printf("=== Jogo de Adivinhacao ===\n");
    printf("Tente adivinhar o numero secreto entre 1 e 100.\n");
    printf("Voce tem %d tentativas.\n\n", max_tent);

    /* Laço principal: continua enquanto não acertou E ainda há tentativas */
    while (acertou == 0 && tentativas < max_tent) {

        tentativas = tentativas + 1;

        printf("Tentativa %d/%d - Digite seu chute: ", tentativas, max_tent);
        scanf("%d", &chute);

        if (chute == secreto) {
            /* Acertou: atualizamos flag para encerrar o laço */
            acertou = 1;

        } else if (chute < secreto) {
            /* Chute foi menor: o secreto está acima */
            printf("  Muito baixo! Tente um numero maior.\n");

        } else {
            /* Chute foi maior: o secreto está abaixo */
            printf("  Muito alto! Tente um numero menor.\n");
        }
    }

    /* Verificamos qual condição encerrou o laço */
    if (acertou == 1) {
        printf("\nParabens! Voce acertou em %d tentativa(s)!\n", tentativas);
    } else {
        printf("\nGame over! O numero secreto era %d.\n", secreto);
    }

    return 0;
}
