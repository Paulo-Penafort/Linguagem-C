/*
 * Exercício 02 — Soma dos Primeiros N Naturais
 * ----------------------------------------------
 * Objetivo: ler N e calcular a soma 1 + 2 + 3 + ... + N.
 *
 * Conceito trabalhado: variável acumuladora — a cada iteração somamos
 * o valor atual de i ao total já acumulado.
 */

#include <stdio.h>

int main() {

    int n;          /* limite superior da soma */
    int i;          /* variável de controle do laço */
    int soma;       /* acumulador: guarda a soma parcial a cada passo */

    /* Leitura */
    printf("Digite o valor de N: ");
    scanf("%d", &n);

    /* Inicializamos a soma em 0, pois ainda não somamos nada */
    soma = 0;

    /* A cada iteração, adicionamos i à soma acumulada.
     * Após o laço, soma conterá 1 + 2 + 3 + ... + n */
    for (i = 1; i <= n; i++) {
        soma = soma + i;   /* equivalente a: soma += i */
    }

    printf("A soma de 1 ate %d e: %d\n", n, soma);

    return 0;
}
