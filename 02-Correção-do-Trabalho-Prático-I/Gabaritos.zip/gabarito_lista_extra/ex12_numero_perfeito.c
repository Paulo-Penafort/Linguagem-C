/*
 * Exercício 12 — Número Perfeito
 * --------------------------------
 * Objetivo: verificar se N é um número perfeito.
 * Um número é perfeito se a soma de seus divisores próprios
 * (todos os divisores exceto ele mesmo) é igual ao próprio número.
 *
 * Exemplos:
 *   6  → divisores próprios: 1, 2, 3  → soma = 6  ✓ perfeito
 *   28 → divisores próprios: 1, 2, 4, 7, 14 → soma = 28 ✓ perfeito
 *   12 → divisores próprios: 1, 2, 3, 4, 6  → soma = 16 ✗ não perfeito
 *
 * Conceito trabalhado: laço de divisibilidade (teste com % == 0)
 * e acumulação condicional da soma dos divisores.
 */

#include <stdio.h>

int main() {

    int n;                /* número a ser verificado */
    int divisor;          /* candidato a divisor (varia de 1 a n-1) */
    int soma_divisores;   /* acumula a soma dos divisores próprios encontrados */
    int eh_perfeito;      /* flag: 1 = perfeito, 0 = não perfeito */

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Informe um numero positivo.\n");
        return 0;
    }

    soma_divisores = 0;

    /* Testamos todos os candidatos de 1 até n-1.
     * Um número 'divisor' é divisor de n se n % divisor == 0 (resto zero). */
    for (divisor = 1; divisor < n; divisor++) {

        if (n % divisor == 0) {
            /* 'divisor' divide n exatamente: é um divisor próprio */
            soma_divisores = soma_divisores + divisor;
        }
    }

    /* Verificamos se a soma dos divisores próprios iguala o número */
    if (soma_divisores == n) {
        eh_perfeito = 1;
    } else {
        eh_perfeito = 0;
    }

    if (eh_perfeito == 1) {
        printf("%d e um numero perfeito! (soma dos divisores = %d)\n", n, soma_divisores);
    } else {
        printf("%d nao e um numero perfeito. (soma dos divisores = %d)\n", n, soma_divisores);
    }

    return 0;
}
