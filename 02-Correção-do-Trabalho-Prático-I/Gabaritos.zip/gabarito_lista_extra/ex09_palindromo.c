/*
 * Exercício 09 — Palíndromo Numérico
 * ------------------------------------
 * Objetivo: verificar se um número é igual ao seu "reverso"
 * usando apenas aritmética (sem strings ou vetores).
 *
 * Estratégia:
 *   1. Guardamos uma cópia do número original.
 *   2. Extraímos os dígitos do número (do menos ao mais significativo)
 *      usando o operador % (resto da divisão por 10).
 *   3. Construímos o número invertido acumulando esses dígitos.
 *   4. Comparamos o invertido com o original.
 *
 * Conceito trabalhado: decomposição de dígitos com % e /.
 */

#include <stdio.h>

int main() {

    int numero;         /* número lido */
    int copia;          /* cópia do número; usamos para extrair os dígitos
                           sem destruir o valor original */
    int invertido;      /* número formado pelos dígitos em ordem inversa */
    int ultimo_digito;  /* dígito extraído em cada iteração */

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &numero);

    /* Guardamos uma cópia para comparar no final */
    copia     = numero;
    invertido = 0;

    /* Enquanto houver dígitos para extrair: */
    while (copia > 0) {

        /* % 10 nos dá o dígito das unidades (o último dígito) */
        ultimo_digito = copia % 10;

        /* Deslocamos o invertido uma casa decimal para a esquerda
         * e adicionamos o novo dígito na posição das unidades.
         * Exemplo: invertido = 0, ultimo_digito = 3  → invertido = 3
         *          invertido = 3, ultimo_digito = 2  → invertido = 32
         *          invertido = 32, ultimo_digito = 1 → invertido = 321 */
        invertido = invertido * 10 + ultimo_digito;

        /* Removemos o dígito que já processamos dividindo por 10 */
        copia = copia / 10;
    }

    /* Se o número original é igual ao seu inverso, é palíndromo */
    if (numero == invertido) {
        printf("%d e palindromo.\n", numero);
    } else {
        printf("%d nao e palindromo (invertido: %d).\n", numero, invertido);
    }

    return 0;
}
