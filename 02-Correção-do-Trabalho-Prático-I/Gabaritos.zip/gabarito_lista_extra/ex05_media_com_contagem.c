/*
 * Exercício 05 — Média com Contagem
 * ------------------------------------
 * Objetivo: ler 10 números reais e calcular:
 *   - a média dos valores positivos
 *   - a quantidade de valores negativos
 * Valores iguais a zero são ignorados nos dois grupos.
 *
 * Conceito trabalhado: contadores e acumuladores condicionais —
 * só atualizamos as variáveis quando a condição for satisfeita.
 */

#include <stdio.h>

int main() {

    int    i;                  /* controle do laço (1 a 10) */
    float  numero;             /* cada número lido pelo usuário */

    float  soma_positivos;     /* acumula a soma dos valores positivos */
    int    qtd_positivos;      /* conta quantos valores positivos foram lidos */
    int    qtd_negativos;      /* conta quantos valores negativos foram lidos */
    float  media_positivos;    /* resultado final: média dos positivos */

    /* Inicialização dos contadores e acumuladores em zero */
    soma_positivos = 0.0;
    qtd_positivos  = 0;
    qtd_negativos  = 0;

    printf("Digite 10 numeros reais:\n");

    for (i = 1; i <= 10; i++) {
        printf("  Numero %d: ", i);
        scanf("%f", &numero);

        if (numero > 0) {
            /* Valor positivo: acumula na soma e conta */
            soma_positivos = soma_positivos + numero;
            qtd_positivos  = qtd_positivos + 1;

        } else if (numero < 0) {
            /* Valor negativo: apenas conta */
            qtd_negativos = qtd_negativos + 1;
        }
        /* Se numero == 0, não fazemos nada (ignorado) */
    }

    /* Calculamos a média dos positivos apenas se houver algum,
     * para evitar divisão por zero */
    if (qtd_positivos > 0) {
        media_positivos = soma_positivos / qtd_positivos;
        printf("\nMedia dos valores positivos: %.2f\n", media_positivos);
    } else {
        printf("\nNenhum valor positivo foi informado.\n");
    }

    printf("Quantidade de valores negativos: %d\n", qtd_negativos);

    return 0;
}
