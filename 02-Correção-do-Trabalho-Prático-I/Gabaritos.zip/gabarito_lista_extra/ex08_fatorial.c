/*
 * Exercício 08 — Fatorial
 * -------------------------
 * Objetivo: ler N (inteiro não-negativo) e calcular N!
 * Por definição: 0! = 1, 1! = 1, N! = N * (N-1) * ... * 2 * 1
 *
 * Conceito trabalhado: produto acumulado e caso base —
 * inicializamos o produto em 1 (elemento neutro da multiplicação)
 * e vamos multiplicando de 2 até N.
 */

#include <stdio.h>

int main() {

    int n;            /* número cujo fatorial será calculado */
    int i;            /* variável de controle do laço */
    long long fat;    /* acumulador do produto; usamos long long para suportar
                         valores maiores sem overflow (ex: 20! = 2.432.902.008.176.640.000) */

    printf("Digite um numero inteiro nao-negativo: ");
    scanf("%d", &n);

    /* Caso base: se n for negativo, o fatorial não é definido */
    if (n < 0) {
        printf("Fatorial nao definido para numeros negativos.\n");
        return 0;
    }

    /* Inicializamos em 1, pois 0! = 1 e 1! = 1.
     * Se n == 0 ou n == 1, o laço não executa nenhuma vez
     * e o resultado final será 1 — que é o correto. */
    fat = 1;

    /* Multiplicamos progressivamente: 1 * 2 * 3 * ... * n */
    for (i = 2; i <= n; i++) {
        fat = fat * i;
    }

    printf("%d! = %lld\n", n, fat);

    return 0;
}
