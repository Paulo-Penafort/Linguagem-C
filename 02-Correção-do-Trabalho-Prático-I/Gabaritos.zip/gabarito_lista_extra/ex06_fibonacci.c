/*
 * Exercício 06 — Sequência de Fibonacci
 * ----------------------------------------
 * Objetivo: ler N e exibir os N primeiros termos de Fibonacci.
 * A sequência começa: 0, 1, 1, 2, 3, 5, 8, 13, ...
 * Cada termo é a soma dos dois anteriores.
 *
 * Conceito trabalhado: atualização simultânea de variáveis auxiliares —
 * precisamos "deslizar" os dois termos anteriores a cada passo.
 */

#include <stdio.h>

int main() {

    int n;           /* quantidade de termos a exibir */
    int i;           /* controle do laço */

    int anterior;    /* guarda o termo F(i-2), o "penúltimo" */
    int atual;       /* guarda o termo F(i-1), o "último" calculado */
    int proximo;     /* o novo termo calculado: F(i) = F(i-1) + F(i-2) */

    printf("Digite a quantidade de termos: ");
    scanf("%d", &n);

    /* Casos especiais: N <= 0 não faz sentido */
    if (n <= 0) {
        printf("Informe um numero positivo.\n");
        return 0;
    }

    /* Os dois primeiros termos são fixos: 0 e 1 */
    anterior = 0;   /* F(0) */
    atual    = 1;   /* F(1) */

    printf("Fibonacci com %d termos: ", n);

    for (i = 1; i <= n; i++) {

        if (i == 1) {
            /* Primeiro termo: sempre 0 */
            printf("%d", anterior);

        } else if (i == 2) {
            /* Segundo termo: sempre 1 */
            printf(" %d", atual);

        } else {
            /* Termos a partir do terceiro: soma dos dois anteriores */
            proximo = anterior + atual;

            printf(" %d", proximo);

            /* Deslizamos a janela: o que era "atual" vira "anterior",
             * e o recém-calculado "proximo" vira o novo "atual" */
            anterior = atual;
            atual    = proximo;
        }
    }

    printf("\n");

    return 0;
}
