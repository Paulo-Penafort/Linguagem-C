/*
 * Exercício 07 — Validação de Senha
 * ------------------------------------
 * Objetivo: simular um sistema de login com no máximo 3 tentativas.
 * Senha correta (definida no código): 1234
 *
 * Conceito trabalhado: laço com múltiplas condições de parada —
 * o laço encerra quando o usuário acerta OU quando esgota as tentativas.
 */

#include <stdio.h>

int main() {

    int senha_correta = 1234;  /* senha definida pelo programador */
    int senha_digitada;        /* senha informada pelo usuário */

    int tentativas;            /* contador de tentativas realizadas */
    int max_tentativas = 3;    /* limite máximo permitido */
    int acertou;               /* flag: 1 = acertou, 0 = errou */

    /* Inicialização */
    tentativas = 0;
    acertou    = 0;  /* começa assumindo que ainda não acertou */

    /* O laço continua enquanto:
     *   - o usuário ainda não acertou   (acertou == 0)
     *   - E ainda há tentativas sobrando (tentativas < max_tentativas)
     */
    while (acertou == 0 && tentativas < max_tentativas) {

        tentativas = tentativas + 1;  /* contamos mais uma tentativa */

        printf("Tentativa %d/%d - Digite a senha: ", tentativas, max_tentativas);
        scanf("%d", &senha_digitada);

        if (senha_digitada == senha_correta) {
            /* Senha correta: atualizamos o flag para sair do laço */
            acertou = 1;
        } else {
            printf("Senha incorreta. Tente novamente.\n");
        }
    }

    /* Após o laço, verificamos qual condição causou a saída */
    if (acertou == 1) {
        printf("Acesso permitido! (tentativas realizadas: %d)\n", tentativas);
    } else {
        printf("Acesso bloqueado! Numero de tentativas esgotado.\n");
    }

    return 0;
}
