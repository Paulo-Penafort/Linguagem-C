#include <stdio.h>

int main() {
    double temperatura;

    printf("Digite a temperatura da pessoa (em C): ");
    scanf("%lf", &temperatura);

    if (temperatura >= 37.5) {
        printf("ESTA COM FEBRE\n");
    } else {
        printf("Nao esta com febre\n");
    }

    return 0;
}
