#include <stdio.h>

int main() {
    int primeiro;
    int segundo;

    printf("Digite o primeiro numero inteiro: ");
    scanf("%d", &primeiro);

    printf("Digite o segundo numero inteiro: ");
    scanf("%d", &segundo);

    if (primeiro % 2 == 0 && segundo % 2 == 0) {
        printf("Os dois sao pares.\n");
    } else if (primeiro % 2 != 0 && segundo % 2 != 0) {
        printf("Os dois sao impares.\n");
    } else if (primeiro % 2 == 0 && segundo % 2 != 0) {
        printf("O primeiro e par e o segundo e impar.\n");
    } else {
        printf("O primeiro e impar e o segundo e par.\n");
    }

    return 0;
}
