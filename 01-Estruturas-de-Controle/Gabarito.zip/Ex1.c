#include <stdio.h>

int main() {
    double distancia_km;
    double tempo_horas;
    double velocidade_media;

    printf("Digite a distancia da viagem em km: ");
    scanf("%lf", &distancia_km);

    printf("Digite o tempo da viagem em horas: ");
    scanf("%lf", &tempo_horas);

    velocidade_media = distancia_km / tempo_horas;

    printf("Velocidade media calculada: %.2lf km/h\n", velocidade_media);

    if (velocidade_media > 110.0) {
        printf("A velocidade media foi superior ao limite de 110 km/h.\n");
    } else {
        printf("A velocidade media nao foi superior ao limite de 110 km/h.\n");
    }

    return 0;
}
