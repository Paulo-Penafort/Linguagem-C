#include <stdio.h>

int main() {
    int numero;

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    if (numero < 0) {
        printf("O numero e negativo.\n");
    } else if (numero == 0) {
        printf("O numero e zero.\n");
    } else {
        printf("O numero e positivo.\n");

        if (numero % 2 == 0) {
            printf("E um numero par.\n");
        } else {
            printf("E um numero impar.\n");
        }
    }

    return 0;
}
