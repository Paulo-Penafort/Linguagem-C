#include <stdio.h>

int main() {
    double peso;
    double altura;
    double imc;

    printf("Digite o peso da pessoa em kg: ");
    scanf("%lf", &peso);

    printf("Digite a altura da pessoa em metros: ");
    scanf("%lf", &altura);

    imc = peso / (altura * altura);

    printf("IMC calculado: %.2lf\n", imc);

    /*
       Classificacao usada:
       IMC < 18.5                 -> Abaixo do peso
       18.5 <= IMC < 25.0         -> Peso normal
       25.0 <= IMC < 30.0         -> Sobrepeso
       30.0 <= IMC < 35.0         -> Obesidade grau I
       35.0 <= IMC < 40.0         -> Obesidade grau II
       IMC >= 40.0                -> Obesidade grau III
    */
    if (imc < 18.5) {
        printf("Classificacao: Abaixo do peso\n");
    } else if (imc < 25.0) {
        printf("Classificacao: Peso normal\n");
    } else if (imc < 30.0) {
        printf("Classificacao: Sobrepeso\n");
    } else if (imc < 35.0) {
        printf("Classificacao: Obesidade grau I\n");
    } else if (imc < 40.0) {
        printf("Classificacao: Obesidade grau II\n");
    } else {
        printf("Classificacao: Obesidade grau III\n");
    }

    return 0;
}
