#include <stdio.h>

int main() {
    int numero1;
    int numero2;

    printf("Digite o primeiro numero: ");
    scanf("%d", &numero1);

    printf("Digite o segundo numero: ");
    scanf("%d", &numero2);

    if (numero1 <= numero2) {
        printf("Ordem crescente: %d %d\n", numero1, numero2);
    } else {
        printf("Ordem crescente: %d %d\n", numero2, numero1);
    }

    return 0;
}
