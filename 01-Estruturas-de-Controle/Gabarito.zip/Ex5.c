#include <stdio.h>

int main() {
    char sexo;

    printf("Digite o sexo da pessoa (M ou F): ");
    scanf(" %c", &sexo);

    if (sexo == 'M' || sexo == 'm') {
        printf("Masculino\n");
    } else if (sexo == 'F' || sexo == 'f') {
        printf("Feminino\n");
    } else {
        printf("Valor invalido para sexo.\n");
    }

    return 0;
}
