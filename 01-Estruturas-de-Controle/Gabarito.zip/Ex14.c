#include <stdio.h>

int main() {
    int codigo;
    int quantidade;
    double valor_unitario;
    double total;

    /*
       Tabela de itens adotada para o exercicio:
       100 -> Cafe expresso pequeno     : R$ 2.00
       101 -> Cafe expresso grande     : R$ 3.00
       102 -> Café com leite pequeno          : R$ 2.50
       103 -> Café com leite grande          : R$ 3.50
       104 -> Água sem gás                : R$ 1.50
       105 -> Agua com gás                  : R$ 2.40
    */

    printf("Digite o codigo do item (100 a 105): ");
    scanf("%d", &codigo);

    printf("Digite a quantidade desejada: ");
    scanf("%d", &quantidade);

    if (codigo == 100) {
        valor_unitario = 2.00;
        total = valor_unitario * quantidade;
        printf("Produto: Cafe expresso pequeno\n");
        printf("Quantidade: %d\n", quantidade);
        printf("Valor unitario: R$ %.2lf\n", valor_unitario);
        printf("Total a pagar: R$ %.2lf\n", total);
    } else if (codigo == 101) {
        valor_unitario = 3.00;
        total = valor_unitario * quantidade;
        printf("Produto: Cafe expresso grande\n");
        printf("Quantidade: %d\n", quantidade);
        printf("Valor unitario: R$ %.2lf\n", valor_unitario);
        printf("Total a pagar: R$ %.2lf\n", total);
    } else if (codigo == 102) {
        valor_unitario = 2.50;
        total = valor_unitario * quantidade;
        printf("Produto: Cafe com leite pequeno\n");
        printf("Quantidade: %d\n", quantidade);
        printf("Valor unitario: R$ %.2lf\n", valor_unitario);
        printf("Total a pagar: R$ %.2lf\n", total);
    } else if (codigo == 103) {
        valor_unitario = 3.50;
        total = valor_unitario * quantidade;
        printf("Produto: Cafe com leite grande\n");
        printf("Quantidade: %d\n", quantidade);
        printf("Valor unitario: R$ %.2lf\n", valor_unitario);
        printf("Total a pagar: R$ %.2lf\n", total);
    } else if (codigo == 104) {
        valor_unitario = 1.50;
        total = valor_unitario * quantidade;
        printf("Produto: Agua sem gas\n");
        printf("Quantidade: %d\n", quantidade);
        printf("Valor unitario: R$ %.2lf\n", valor_unitario);
        printf("Total a pagar: R$ %.2lf\n", total);
    } else if (codigo == 105) {
        valor_unitario = 2.40;
        total = valor_unitario * quantidade;
        printf("Produto: Agua com gas\n");
        printf("Quantidade: %d\n", quantidade);
        printf("Valor unitario: R$ %.2lf\n", valor_unitario);
        printf("Total a pagar: R$ %.2lf\n", total);
    } else {
        printf("Codigo invalido. Nenhum item encontrado.\n");
    }

    return 0;
}
