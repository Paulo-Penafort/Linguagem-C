#include <stdio.h>

int main() {
    int numero;

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    if (numero > 7) {
        printf("O numero e maior que 7.\n");
    } else {
        printf("O numero nao e maior que 7.\n");
    }

    return 0;
}
