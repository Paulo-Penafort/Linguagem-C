#include <stdio.h>

int main() {
    double nota1;
    double nota2;
    double nota3;
    int faltas;
    double media;
    int conceito;

    /*
       Observacao didatica:
       Como a tabela de conceitos nao foi enviada junto com o enunciado textual,
       foi adotada a seguinte tabela (conceito inteiro):
       media >= 9.0  -> conceito 5
         8.0 <= media < 9.0  -> conceito 4
         7.0 <= media < 8.0  -> conceito 3
         6.0 <= media < 7.0  -> conceito 2
         media < 6.0         -> conceito 0
       Se faltas > 5, conceito = 0 (regra obrigatoria do enunciado).
    */

    printf("Digite a primeira nota: ");
    scanf("%lf", &nota1);

    printf("Digite a segunda nota: ");
    scanf("%lf", &nota2);

    printf("Digite a terceira nota: ");
    scanf("%lf", &nota3);

    printf("Digite a quantidade de faltas: ");
    scanf("%d", &faltas);

    media = (nota1 + nota2 + nota3) / 3.0;

    if (faltas > 5) {
        conceito = 0;
    } else if (media >= 9.0) {
        conceito = 5;
    } else if (media >= 8.0) {
        conceito = 4;
    } else if (media >= 7.0) {
        conceito = 3;
    } else if (media >= 6.0) {
        conceito = 2;
    } else {
        conceito = 0;
    }

    printf("Media calculada: %.2lf\n", media);
    printf("Conceito do aluno: %d\n", conceito);

    return 0;
}
