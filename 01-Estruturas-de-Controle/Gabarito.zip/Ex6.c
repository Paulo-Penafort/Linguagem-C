#include <stdio.h>

int main() {
    int numero_mes;

    printf("Digite um numero inteiro de 1 a 12: ");
    scanf("%d", &numero_mes);

    if (numero_mes == 1) {
        printf("Mes de janeiro\n");
    } else if (numero_mes == 2) {
        printf("Mes de fevereiro\n");
    } else if (numero_mes == 3) {
        printf("Mes de marco\n");
    } else if (numero_mes == 4) {
        printf("Mes de abril\n");
    } else if (numero_mes == 5) {
        printf("Mes de maio\n");
    } else if (numero_mes == 6) {
        printf("Mes de junho\n");
    } else if (numero_mes == 7) {
        printf("Mes de julho\n");
    } else if (numero_mes == 8) {
        printf("Mes de agosto\n");
    } else if (numero_mes == 9) {
        printf("Mes de setembro\n");
    } else if (numero_mes == 10) {
        printf("Mes de outubro\n");
    } else if (numero_mes == 11) {
        printf("Mes de novembro\n");
    } else if (numero_mes == 12) {
        printf("Mes de dezembro\n");
    } else {
        printf("O valor nao corresponde a nenhum mes.\n");
    }

    return 0;
}
