#include <stdio.h>

int main() {
    int hora;
    int minuto;
    int segundo;

    printf("Digite a hora: ");
    scanf("%d", &hora);

    printf("Digite o minuto: ");
    scanf("%d", &minuto);

    printf("Digite o segundo: ");
    scanf("%d", &segundo);

    if (hora < 0 || hora > 23) {
        printf("Horario invalido.\n");
    } else if (minuto < 0 || minuto > 59) {
        printf("Horario invalido.\n");
    } else if (segundo < 0 || segundo > 59) {
        printf("Horario invalido.\n");
    } else {
        printf("Horario valido.\n");
    }

    return 0;
}
